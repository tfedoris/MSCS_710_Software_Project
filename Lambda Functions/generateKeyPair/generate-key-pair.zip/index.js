const NodeRSA = require("keypair");

exports.handler = (event) => {
  var response = {
    success: false,
    data: {},
  };

  const pair = keypair(1024);

  response.success = true;
  response.data = {
    publicKey: pair.public,
    privateKey: pair.private,
  };
};
