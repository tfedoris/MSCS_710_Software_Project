// console.log(connection);
exports.handler = (event, context, callback) => {
  var mysql = require("mysql");
  var connection = mysql.createConnection({
    host: "wardatabase.cm9i2tottiif.us-west-2.rds.amazonaws.com",
    user: "admin",
    password: "12345678",
    database: "waruserinfo",
  });

  const query = `SELECT user_id, public_key FROM registration_info WHERE registration_id=?`;

  connection.query(
    query,
    event.registration_id,
    function (error, results, fields) {
      if (error) {
        connection.destroy();
        console.log("Error");
        throw error;
      } else {
        // connected!
        console.log(results);
        const response = {
          success: true,
          data: results[0],
        };
        callback(error, response);
        connection.end(function (err) {
          const errorResponse = {
            success: false,
            data: err,
          };
          callback(errorResponse, results);
        });
      }
    }
  );
};
