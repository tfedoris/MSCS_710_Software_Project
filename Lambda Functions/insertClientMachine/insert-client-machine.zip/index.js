const axios = require("axios");

exports.handler = async (event, context, callback) => {
  var mysql = require("mysql");
  var connection = mysql.createConnection({
    host: "wardatabase.cm9i2tottiif.us-west-2.rds.amazonaws.com",
    user: "admin",
    password: "12345678",
    database: "warproject",
  });

  axios
    .post(
      "https://ytp3g6j58c.execute-api.us-east-2.amazonaws.com/test/get-registration-info",
      {
        registration_id: event.registration_id,
      }
    )
    .then(
      (response) => {
        console.log(response);
      },
      (error) => {
        console.log(error);
      }
    );

  //   const query = `INSERT INTO client_machine VALUES (
  //     '${event.machine_id}',
  //     '${event.entry_time}',
  //     '${event.machine_name}',
  //     '${event.system_name}',
  //     '${event.version}',
  //     '${event.machine_type}',
  //     '${event.nounce}',
  //     '${event.session_id}'
  //     )`;

  //   connection.query(query, function (error, results, fields) {
  //     if (error) {
  //       connection.destroy();
  //       console.log("Error");
  //       throw error;
  //     } else {
  //       // connected!
  //       console.log(results);
  //       const response = {
  //         success: true,
  //         data: results[0],
  //       };
  //       callback(error, response);
  //       connection.end(function (err) {
  //         const errorResponse = {
  //           success: false,
  //           data: err,
  //         };
  //         callback(errorResponse, results);
  //       });
  //     }
  //   });
};
